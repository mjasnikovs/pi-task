package config

import (
	"encoding/json"
	"os"
)

// Config holds the application configuration loaded from config.json.
type Config struct {
	Name       string `json:"name"`
	Port       int    `json:"port"`
	AdminEmail string `json:"adminEmail"`
}

// LoadConfig reads ./config.json from the current working directory and
// decodes it into a Config. It returns the zero Config and a non-nil error
// if the file cannot be read or is not valid JSON.
func LoadConfig() (Config, error) {
	var cfg Config
	data, err := os.ReadFile("./config.json")
	if err != nil {
		return Config{}, err
	}
	if err := json.Unmarshal(data, &cfg); err != nil {
		return Config{}, err
	}
	return cfg, nil
}
