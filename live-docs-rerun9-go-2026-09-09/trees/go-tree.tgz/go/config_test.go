package main

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"

	"go.uber.org/zap"

	"docs-live-go/config"
)

// chdirTemp moves the process CWD into a fresh t.TempDir() and restores the
// original CWD when the test finishes. Tests that chdir must not be run in
// parallel.
func chdirTemp(t *testing.T) string {
	t.Helper()
	dir := t.TempDir()
	old, err := os.Getwd()
	if err != nil {
		t.Fatalf("get cwd: %v", err)
	}
	if err := os.Chdir(dir); err != nil {
		t.Fatalf("chdir into temp dir: %v", err)
	}
	t.Cleanup(func() {
		if err := os.Chdir(old); err != nil {
			t.Errorf("restore original cwd %s: %v", old, err)
		}
	})
	return dir
}

func TestConfigRouteSuccess(t *testing.T) {
	dir := chdirTemp(t)
	want := config.Config{Name: "docs-live", Port: 9090, AdminEmail: "admin@example.com"}
	fixture, err := json.Marshal(want)
	if err != nil {
		t.Fatalf("marshal fixture: %v", err)
	}
	if err := os.WriteFile(filepath.Join(dir, "config.json"), fixture, 0o600); err != nil {
		t.Fatalf("write fixture: %v", err)
	}

	w := httptest.NewRecorder()
	engine := newEngine(zap.NewNop())
	engine.ServeHTTP(w, httptest.NewRequest(http.MethodGet, "/config", nil))

	if w.Code != http.StatusOK {
		t.Fatalf("want status 200, got %d (body: %s)", w.Code, w.Body.String())
	}
	var got config.Config
	if err := json.Unmarshal(w.Body.Bytes(), &got); err != nil {
		t.Fatalf("response body is not raw config.Config JSON: %v (body: %s)", err, w.Body.String())
	}
	if got != want {
		t.Fatalf("round-tripped config mismatch: want %+v, got %+v", want, got)
	}
	if got.Name != want.Name {
		t.Errorf("Name: want %q, got %q", want.Name, got.Name)
	}
	if got.Port != want.Port {
		t.Errorf("Port: want %d, got %d", want.Port, got.Port)
	}
	if got.AdminEmail != want.AdminEmail {
		t.Errorf("AdminEmail: want %q, got %q", want.AdminEmail, got.AdminEmail)
	}
}

func TestConfigRouteDecodeFailure(t *testing.T) {
	dir := chdirTemp(t)
	if err := os.WriteFile(filepath.Join(dir, "config.json"), []byte("{not valid json"), 0o600); err != nil {
		t.Fatalf("write fixture: %v", err)
	}

	w := httptest.NewRecorder()
	engine := newEngine(zap.NewNop())
	engine.ServeHTTP(w, httptest.NewRequest(http.MethodGet, "/config", nil))

	if w.Code != http.StatusBadRequest {
		t.Fatalf("want status 400, got %d (body: %s)", w.Code, w.Body.String())
	}
	var envelope struct {
		Error string `json:"error"`
	}
	if err := json.Unmarshal(w.Body.Bytes(), &envelope); err != nil {
		t.Fatalf("response body is not a JSON error envelope: %v (body: %s)", err, w.Body.String())
	}
	if envelope.Error == "" {
		t.Errorf("error field missing or empty (body: %s)", w.Body.String())
	}
}
