package main

import (
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"

	"docs-live-go/config"
)

// newEngine constructs the gin Engine (no middleware) with the GET /config
// route. It never starts a listener, so tests can drive the handler via
// httptest.
func newEngine(logger *zap.Logger) *gin.Engine {
	engine := gin.New()
	engine.GET("/config", func(c *gin.Context) {
		cfg, err := config.LoadConfig()
		if err != nil {
			logger.Error("failed to load config", zap.String("error", err.Error()))
			c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
			return
		}
		logger.Info("loaded config", zap.String("name", cfg.Name), zap.Int("port", cfg.Port))
		c.JSON(http.StatusOK, cfg)
	})
	return engine
}

func main() {
	logger, err := zap.NewProduction()
	if err != nil {
		logger = zap.NewNop()
	}
	defer logger.Sync()

	cfg, err := config.LoadConfig()
	if err != nil {
		logger.Error("failed to load config for bind address", zap.String("error", err.Error()))
	}
	if cfg.Port == 0 {
		cfg.Port = 8123
	}
	addr := fmt.Sprintf(":%d", cfg.Port)

	newEngine(logger).Run(addr)
}
