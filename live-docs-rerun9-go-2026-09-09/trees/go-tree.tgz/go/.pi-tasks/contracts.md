"Build a config package in Go" [anchor: design preamble]
"expose LoadConfig() that reads config.json from the module root and decodes it into a Config struct holding a string Name, an int Port and a string AdminEmail" [anchor: (1)]
"expose a gin Engine serving GET /config" [anchor: (2)]
"returns the config as JSON on success and HTTP 400 with a JSON error body when config.json fails to decode" [anchor: (2)]
