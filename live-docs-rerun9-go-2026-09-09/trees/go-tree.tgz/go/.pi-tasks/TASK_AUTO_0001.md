---
id: TASK_AUTO_0001
state: completed
phase: done
created_at: 2026-09-09T06:00:24.914Z
updated_at: 2026-09-09T06:20:13.050Z
title: Build a config package in Go. It must: (1) expose LoadConfig() that reads config.json from the module root and decodes it into a Config struct holding a string Name, an int Port and a string AdminEmail; (2) expose a gin Engine serving GET /config, which returns the config as JSON on success and HTTP 400 with a JSON error body when config.json fails to decode; (3) log both outcomes with a zap logger; (4) cover both responses in config_test.go, passing under `go test ./...`.
---

## feature prompt

Build a config package in Go. It must: (1) expose LoadConfig() that reads config.json from the module root and decodes it into a Config struct holding a string Name, an int Port and a string AdminEmail; (2) expose a gin Engine serving GET /config, which returns the config as JSON on success and HTTP 400 with a JSON error body when config.json fails to decode; (3) log both outcomes with a zap logger; (4) cover both responses in config_test.go, passing under `go test ./...`.

## clarifications

Q1: What exact JSON body should the 400 response carry (and should the success body be the raw Config struct)? This is the one cross-cutting shape the spec leaves open, and it must be settled up front because the handler and the config_test.go assertions both depend on the same field names — so the route task and the test task can be written independently without rework.
A1: success body is the raw Config struct marshaled to JSON ({"Name":..., "Port":..., "AdminEmail":...} — the spec says "returns the config as JSON"); the 400 body should be a single standard error envelope {"error": "<message>"} where <message> describes the decode failure (e.g. "failed to decode config.json: <err>"), so the handler and test assertions share one field name. (auto-resolved — already settled by the spec)
Q2: Since the spec pins a no-arg LoadConfig(), how does it locate config.json — as ./config.json relative to the process CWD, or by discovering the module root (e.g. walking up to go.mod) — and consequently, is config_test.go hermetic (its own fixtures) or run against the repo's real config.json? The repo already has a valid config.json at the root (keys name/port/adminEmail, which decode fine into Name/Port/AdminEmail case-insensitively), so the failure-path test needs a way to force a decode error without corrupting that file; the path strategy decides whether the test task can be written as an independent, hermetic unit or must coordinate with the real file.
A2: CWD-relative "./config.json" with hermetic tests — LoadConfig() simply reads "./config.json" from the process working directory (no go.mod walking), and config_test.go uses t.TempDir() fixtures plus os.Chdir (with restore) to exercise both the success decode and the forced-decode-error path without ever touching the repo's real root config.json. (auto-resolved — already settled by the spec)
Q3: Does the config package live in a dedicated config/ subpackage (with main.go later wired to build and run the gin engine), or does everything — Config, LoadConfig, the Engine, and config_test.go — stay in the root main package alongside the existing stub main.go? This is the last structural fork: it decides the file/task layout (whether a separate "wire main.go" task exists at all, whether tests are in-package or cross-package, and where config_test.go physically lives), and it constrains how the exported engine is exposed (config.NewEngine import vs. a plain identifier in main).
A3: dedicated config/ subpackage — the task says "build a config package" and "expose LoadConfig()" / "expose a gin Engine," i.e. an importable named package (package config in ./config/) containing Config, LoadConfig, the exported engine, and config_test.go as an in-package test; the existing root stub main.go is left untouched for a later wiring task, so its current contents must be preserved. (auto-resolved — already settled by the spec)

## tasks

- [x] TASK_0001  Create config/ subpackage with Config struct and LoadConfig() decoding CWD-relative "./config.json" into Name/Port/AdminEmail | decisions (explicit user choices — these OVERRIDE the spec doc wherever they conflict; follow them exactly): "use CWD-relative ./config.json with no go.mod walking"; "use dedicated config/ subpackage, leave root main.go untouched"
- [x] TASK_0002  Expose gin Engine with GET /config returning Config JSON on success and 400 {"error":"…"} on decode failure, logging both outcomes with zap | decisions (explicit user choices — these OVERRIDE the spec doc wherever they conflict; follow them exactly): "success body is raw Config struct JSON; 400 body is single-field envelope {\"error\":\"<message>\"}"; "use dedicated config/ subpackage, leave root main.go untouched"
- [x] TASK_0003  Write config_test.go covering both /config responses with hermetic t.TempDir()+os.Chdir fixtures, passing under `go test ./...` | decisions (explicit user choices — these OVERRIDE the spec doc wherever they conflict; follow them exactly): "use CWD-relative ./config.json with t.TempDir() and os.Chdir (restore) for hermetic tests"; "success body is raw Config struct JSON; 400 body is single-field envelope {\"error\":\"<message>\"}"

## coverage

5 grounded requirement(s): 5 task-mapped, 0 cross-cutting (carried into every task via .pi-tasks/requirements.md), 0 unowned

## gates

- 2026-09-09T06:20:13.049Z final-gate: PASS — statics + `go mod verify`, `go test ./...`, `go build ./...` passed
