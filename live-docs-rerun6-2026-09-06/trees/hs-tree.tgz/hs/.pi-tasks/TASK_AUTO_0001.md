---
id: TASK_AUTO_0001
state: in_progress
phase: done
created_at: 2026-09-06T17:03:56.065Z
updated_at: 2026-09-06T17:03:56.111Z
title: Build a config module in Haskell. It must: (1) expose loadConfig that reads config.json from the project root and decodes it with aeson into a Config record holding a Text name, an Int port and a Text adminEmail; (2) expose a scotty application serving GET /config, which returns the config as JSON on success and HTTP 400 with a JSON error body when config.json fails to decode; (3) cover both responses in test/Spec.hs, passing under `cabal test`.
---

## feature prompt

Build a config module in Haskell. It must: (1) expose loadConfig that reads config.json from the project root and decodes it with aeson into a Config record holding a Text name, an Int port and a Text adminEmail; (2) expose a scotty application serving GET /config, which returns the config as JSON on success and HTTP 400 with a JSON error body when config.json fails to decode; (3) cover both responses in test/Spec.hs, passing under `cabal test`.

## clarifications

Q1: Does loadConfig take an injectable file path, or is it hard-wired to config.json at the project root? This is the fork that ripples through every subsystem: it sets the signature of the spec's named API, determines whether the scotty route can be pointed at a fixture, and dictates how the test exercises the HTTP 400 decode-failure branch — with an injectable path the test loads a deliberately broken fixture file, while a hard-wired path forces the test to temporarily corrupt the real config.json (fragile, non-parallel-safe).
A1: loadConfig :: FilePath -> IO (Either Aeson.Decoder Config) plus a no-arg wrapper loadDefaultConfig that passes "config.json"; the scotty app takes the path as a parameter (defaulting to root), and test/Spec.hs covers the 400 case by serving from a small broken fixture file, with no real files mutated (YOLO)
Q2: How does test/Spec.hs drive the scotty app to observe both responses — by exposing the route handlers as an in-process WAI Application and invoking them with wai-test, or by spinning up a real Warp server on an ephemeral port and hitting it with an HTTP client (http-conduit/http-client)? This fork is still open and it decides the test's dependency set and the shape of the "expose scotty application" task: wai-test (no sockets, no port contention, deterministic) versus a real server plus an HTTP client (extra deps, must pick/manage a free port, mildly flaky).
A2: Expose the Scotty app as a WAI Application (e.g. via `warp`-compatible `ScottyM ()` → `Application` conversion) and drive it in-process with wai-test — this is the standard convention for testing WAI/Scotty apps in Haskell (no sockets, no port management, deterministic, and one fewer dependency than a real-server + http-client setup). (auto-resolved — already settled by the spec)
Q3: What exactly should the HTTP 400 JSON error body contain — a minimal {"error":"<decoder message>"} object, or a richer structured body (e.g. an error code plus path/details)? This is the last open fork: it decides whether the route and the test share a small error-encoding helper (an extra module/task) or the body is built inline, and it pins exactly what test/Spec.hs asserts for the 400 branch.
A3: a minimal {"error":"<Aeson decoder message>"} object built inline in the route (no shared error type), so the test asserts status 400 plus that the body parses to a JSON object carrying an error key whose value is non-empty — keeping the breakdown to the three subsystems the spec names (decode module, scotty app, spec) with no extra shared-encoding task. (YOLO)

## tasks

- [ ] TASK_0001  Scaffold the cabal project — .cabal file with aeson, scotty, wai-test, text deps; src/ and test/ layout; valid config.json at project root
- [ ] Implement Config record, FromJSON instance, and loadConfig — `loadConfig :: FilePath -> IO (Either Aeson.Decoder Config)` plus no-arg `loadDefaultConfig` | decisions (explicit user choices — these OVERRIDE the spec doc wherever they conflict; follow them exactly): "loadConfig takes an injectable FilePath with a no-arg loadDefaultConfig wrapper passing \"config.json\""
- [ ] Build scotty GET /config route and expose the app as a WAI Application — path parameter defaulting to root; 400 body as inline {"error":"<decoder message>"} | decisions (explicit user choices — these OVERRIDE the spec doc wherever they conflict; follow them exactly): "scotty app takes the config path as a parameter defaulting to root; expose the app as a WAI Application via ScottyM () → Application conversion for in-process testing; build the 400 error body inline as a minimal {\"error\":\"<decoder message>\"} object with no shared error type"
- [ ] Write test/Spec.hs covering 200 and 400 responses under cabal test — drive the WAI app in-process with wai-test; broken fixture for the 400 branch; assert non-empty "error" key | decisions (explicit user choices — these OVERRIDE the spec doc wherever they conflict; follow them exactly): "drive the app in-process with wai-test, not a real server; cover the 400 case by serving from a small broken fixture file with no real files mutated; assert status 400 plus body parses to a JSON object carrying a non-empty error key"

## coverage

4 grounded requirement(s): 4 task-mapped, 0 cross-cutting (carried into every task via .pi-tasks/requirements.md), 0 unowned
