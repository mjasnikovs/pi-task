"Build a config module in TypeScript." [anchor: prose]
