---
id: TASK_AUTO_0001
state: completed
phase: done
created_at: 2026-09-06T15:24:59.990Z
updated_at: 2026-09-06T15:59:31.514Z
title: Build a config module in TypeScript. It must: (1) export loadConfig() that reads config.json from the project root and validates it with zod, requiring a string name, a port between 1 and 65535, and an admin email; (2) export a hono app serving GET /config, which returns the config as JSON on success and HTTP 400 with the zod validation issues when config.json is invalid; (3) cover both responses in test/config.test.ts, passing under `bun test`.
---

## feature prompt

Build a config module in TypeScript. It must: (1) export loadConfig() that reads config.json from the project root and validates it with zod, requiring a string name, a port between 1 and 65535, and an admin email; (2) export a hono app serving GET /config, which returns the config as JSON on success and HTTP 400 with the zod validation issues when config.json is invalid; (3) cover both responses in test/config.test.ts, passing under `bun test`.

## clarifications

Q1: Should loadConfig() re-read and re-parse config.json on every call (so GET /config always reflects the file), or load it once at module startup and cache the result? This is the fork that most changes the split: it determines whether the 400-path test in test/config.test.ts can simply overwrite config.json and fire app.request(), or whether the app/task needs a cache-invalidation or fresh-process strategy — and it changes whether the loader and route are one cohesive unit or two (loader + cache + route).
A1: subdivide into smaller per-deliverable tasks — one task per route, page, screen, module, schema, or pipeline stage — rather than one task per milestone or spec section. A milestone or section that spans several deliverables becomes several tasks. (host-set: the spec fixes the build ORDER, not the task breakdown, so pi-task settles granularity deterministically instead of guessing per run) (host-set — plan granularity is not left to chance)
Q2: What is loadConfig()'s error contract when config.json is invalid — does it throw a typed error carrying the zod issues, or return a result union the route inspects? This is the interface between the loader task and the route task: the spec requires the route to return the zod issues on HTTP 400, so loadConfig() must expose them somehow, and the choice dictates whether the route task is a try/catch or a switch over a union — it fixes the shared type the loader deliverable must produce before the route deliverable starts.
A2: loadConfig() throws a typed error (e.g. class ConfigValidationError extends Error { issues: ZodIssue[] }) on invalid config, and the route catches it in a try/catch to return 400 with e.issues; on success it returns the parsed config directly. This is the idiomatic Hono/Express pattern, keeps the loader signature clean (returns Config | never), and is trivially reversible for a module this size. (auto-resolved — already settled by the spec)

## tasks

- [x] TASK_0001  Define zod schema for config — name (string), port (int 1–65535), admin email
- [x] TASK_0002  Implement loadConfig() and ConfigValidationError — reads config.json from project root, validates with zod, throws typed error carrying issues on failure, returns parsed config on success | decisions (explicit user choices — these OVERRIDE the spec doc wherever they conflict; follow them exactly): loadConfig() throws a typed error (class ConfigValidationError extends Error { issues: ZodIssue[] }) on invalid config and returns the parsed config directly on success
- [x] TASK_0003  Implement Hono app with GET /config route — calls loadConfig(), returns config as JSON on success, catches ConfigValidationError and returns 400 with e.issues | decisions (explicit user choices — these OVERRIDE the spec doc wherever they conflict; follow them exactly): route catches ConfigValidationError in a try/catch to return 400 with e.issues
- [x] TASK_0004  Write tests in test/config.test.ts covering both 200 and 400 responses — passing under `bun test`

## coverage

7 grounded requirement(s): 6 task-mapped, 1 cross-cutting (carried into every task via .pi-tasks/requirements.md), 0 unowned
- carried: "Build a config module in TypeScript."

## gates

- 2026-09-06T15:59:31.513Z final-gate: PASS — statics + `npm ci --dry-run` passed
