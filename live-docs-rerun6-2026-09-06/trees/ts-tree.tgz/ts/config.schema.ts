import { z } from "zod";

export const configSchema = z.object({
  name: z.string(),
  port: z.number().int().min(1).max(65535),
  adminEmail: z.string().email(),
});

export type Config = z.infer<typeof configSchema>;
