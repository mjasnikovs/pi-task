import { readFile } from "node:fs/promises";
import { Hono } from "hono";
import { fileURLToPath } from "node:url";
import { z } from "zod";
import type * as core from "zod/v4/core";

/** A valid port: a safe integer in 1–65535 (zod reports failures with the generic `invalid_type` code). */
const isPort = (v: unknown): boolean =>
  typeof v === "number" && Number.isSafeInteger(v) && v >= 1 && v <= 65535;

export const configSchema = z.object({
  name: z.string(),
  port: z.number().superRefine((value, ctx) => {
    if (!isPort(value)) {
      ctx.addIssue({
        code: "invalid_type",
        message: `Invalid input: expected a port (int 1–65535), received ${typeof value === "number" ? String(value) : typeof value}`,
      });
    }
  }),
  adminEmail: z.string().email(),
});

export type Config = z.infer<typeof configSchema>;

/**
 * Thrown when config.json is missing, malformed, or fails schema validation.
 * `issues` is always a JSON-serializable array: the zod issue list for a
 * validation failure, `[]` for a missing file, or a single synthetic issue
 * describing a JSON parse error.
 */
export class ConfigValidationError extends Error {
  issues: core.$ZodIssue[];

  constructor(issues: core.$ZodIssue[], message?: string) {
    super(message ?? "Invalid config.json");
    this.name = "ConfigValidationError";
    this.issues = issues;
  }
}

const CONFIG_PATH = fileURLToPath(new URL("./config.json", import.meta.url));

/**
 * Reads config.json from the project root and validates it with zod.
 * Returns the parsed config object directly; throws ConfigValidationError on
 * a missing file, malformed JSON, or schema validation failure.
 */
export async function loadConfig(): Promise<Config> {
  let raw: string;
  try {
    raw = await readFile(CONFIG_PATH, "utf8");
  } catch (err) {
    if (err instanceof Error && "code" in err && (err as NodeJS.ErrnoException).code === "ENOENT") {
      throw new ConfigValidationError([], "config.json not found");
    }
    throw err;
  }

  let data: unknown;
  try {
    data = JSON.parse(raw);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    const syntheticIssue: core.$ZodIssue = {
      code: "custom",
      input: raw,
      path: [],
      message: `config.json is not valid JSON: ${message}`,
    };
    throw new ConfigValidationError([syntheticIssue], "config.json is not valid JSON");
  }

  const result = configSchema.safeParse(data);
  if (!result.success) {
    throw new ConfigValidationError(result.error.issues, "config.json failed validation");
  }
  return result.data;
}

export const app = new Hono();

app.get("/config", async (c) => {
  try {
    const config = await loadConfig();
    return c.json(config);
  } catch (e) {
    if (e instanceof ConfigValidationError) {
      return c.json(e.issues, 400);
    }
    throw e;
  }
});
