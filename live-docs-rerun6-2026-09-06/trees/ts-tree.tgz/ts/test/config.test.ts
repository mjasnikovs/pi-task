import { afterAll, describe, expect, it } from "bun:test";
import { readFile, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { app } from "../config.ts";

const CONFIG_PATH = fileURLToPath(new URL("../config.json", import.meta.url));
const VALID_CONFIG = {
  name: "live-docs-check",
  port: 8123,
  adminEmail: "ops@example.com",
};

const originalConfigRaw = await readFile(CONFIG_PATH, "utf8");

afterAll(async () => {
  await writeFile(CONFIG_PATH, originalConfigRaw, "utf8");
});

describe("GET /config", () => {
  it("returns 200 and the config object when config.json is valid", async () => {
    const res = await app.request("/config");
    expect(res.status).toBe(200);
    expect(await res.json()).toEqual(VALID_CONFIG);
  });

  it("returns 400 and the zod issues array when config.json is invalid", async () => {
    const invalidConfig = { ...VALID_CONFIG, port: 70000 };
    await writeFile(CONFIG_PATH, JSON.stringify(invalidConfig), "utf8");
    try {
      const res = await app.request("/config");
      expect(res.status).toBe(400);
      const body = await res.json();
      expect(Array.isArray(body)).toBe(true);
      expect(body.length).toBeGreaterThan(0);
      for (const issue of body) {
        expect(typeof issue.message).toBe("string");
        expect(issue.message.length).toBeGreaterThan(0);
      }
    } finally {
      await writeFile(CONFIG_PATH, originalConfigRaw, "utf8");
    }
  });
});
