{-# LANGUAGE OverloadedStrings #-}
module Main (main) where

import Web.Scotty
import Network.HTTP.Types (status200, status400)
import Control.Exception (try, SomeException, displayException)
import Data.Aeson (object, (.=), decode)
import Data.Aeson.Key (fromText)
import qualified Data.ByteString.Lazy as BL
import qualified Data.Text as T

import Config (Config (..), loadConfig)

-- | Try to read the port from config.json at startup.
-- If the file is missing or invalid, fall back to 8125.
startupPort :: IO Int
startupPort = do
  let loadPort :: IO Int
      loadPort = do
        bs <- BL.readFile "config.json"
        case decode bs :: Maybe Config of
          Just cfg -> pure (port cfg)
          Nothing  -> pure 8125
  r <- (try loadPort :: IO (Either SomeException Int))
  case r of
    Left _  -> pure 8125
    Right p -> pure p

app :: ScottyM ()
app = get "/config" $ do
  result <- liftIO $ try (loadConfig :: IO Config)
  case result of
    Right cfg -> do
      status status200
      json cfg
    Left e -> do
      status status400
      json (object [(fromText (T.pack "error")) .= T.takeWhile (/= '\n') (T.pack (displayException (e :: SomeException)))])

main :: IO ()
main = do
  p <- startupPort
  scotty p app
