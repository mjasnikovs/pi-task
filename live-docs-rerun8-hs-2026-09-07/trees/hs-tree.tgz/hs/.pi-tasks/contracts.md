"a Config record holding a Text name, an Int port and a Text adminEmail" [anchor: (1)]
"expose loadConfig that reads config.json from the project root and decodes it with aeson into a Config record" [anchor: (1)]
"a scotty application serving GET /config, which returns the config as JSON on success and HTTP 400 with a JSON error body when config.json fails to decode" [anchor: (2)]
"cover both responses in test/Spec.hs, passing under `cabal test`" [anchor: (3)]
