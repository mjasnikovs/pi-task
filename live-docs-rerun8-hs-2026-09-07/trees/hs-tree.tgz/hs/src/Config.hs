{-# LANGUAGE DeriveGeneric #-}
module Config
  ( Config(..)
  , loadConfigFile
  , loadConfig
  ) where

import Data.Aeson (FromJSON (..), ToJSON (..), genericParseJSON, genericToJSON, defaultOptions, decode)
import qualified Data.ByteString.Lazy as BL
import qualified Data.Text as T
import System.IO (readFile)
import GHC.Generics (Generic)

data Config = Config
  { name       :: T.Text
  , port       :: Int
  , adminEmail :: T.Text
  } deriving (Generic)

instance FromJSON Config where
  parseJSON = genericParseJSON defaultOptions

instance ToJSON Config where
  toJSON = genericToJSON defaultOptions

-- | Read the JSON file at the given path and decode it into a 'Config'.
loadConfigFile :: FilePath -> IO Config
loadConfigFile path = do
  contents <- BL.readFile path
  case decode contents of
    Nothing   -> error ("loadConfigFile: failed to decode config from " ++ show path)
    Just cfg  -> pure cfg

-- | Load the config from "config.json" in the current working directory.
loadConfig :: IO Config
loadConfig = loadConfigFile "config.json"
