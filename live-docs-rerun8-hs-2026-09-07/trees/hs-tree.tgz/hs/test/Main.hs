-- | GHC's `-fbuilding-cabal-package` mode (used by cabal for executables
-- and test suites) refuses to link a module that is not named `Main`
-- (it fails with "There is no module named `Main`"). Since `main-is`
-- must name a file that GHC can link, we provide a trivial `Main` shim
-- that simply forwards to the real test-suite entry point in `Spec.hs`.
-- The actual hspec suite lives in `Spec.hs` (module `Spec (main)`), as
-- required by the cross-slice contract.
module Main (main) where

import Spec (main)
