{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE OverloadedStrings #-}
module Spec (main) where

import Control.Exception (try, SomeException)
import Control.Exception.Base (bracket)
import Data.Aeson (decode, encode, object, (.=), Value (Object))
import Data.Aeson.KeyMap (toList)
import Data.ByteString (toStrict)
import Data.IORef (IORef, atomicModifyIORef', newIORef)
import Data.Maybe (fromMaybe)
import qualified Data.ByteString.Lazy as BL
import qualified Data.Text as T
import Network.HTTP.Types (Status, status200, status400)
import Network.Wai (Application, responseLBS)
import Network.Wai.Test (SResponse (..), defaultRequest, request,
                         runSession, setPath)
import System.Directory (createDirectoryIfMissing, getCurrentDirectory,
                         removeDirectoryRecursive, setCurrentDirectory)
import System.Environment (lookupEnv)
import System.FilePath ((</>))
import System.IO (hClose, hPutStr, openFile, IOMode (..))
import System.IO.Unsafe (unsafePerformIO)
import Test.Hspec (hspec, it, shouldBe)

import Config (Config (..), loadConfig)

-- | Design rationale: the scotty app's `app :: ScottyM ()` lives in the
-- executable module `app/Main.hs`, which exports only `main`, so it is
-- NOT importable from any library. The library exposes only `Config`,
-- `loadConfigFile`, and `loadConfig` from `src/Config.hs`. We therefore
-- build the tested WAI handler inline, calling the exact same
-- `loadConfig` the scotty app calls, so the 200/400 behavior matches the
-- real app's contract. `loadConfigFile` fails by raising (an uncaught
-- `SomeException`), so it is observed via `try`.
--
-- Note: wai-test >= 3.0 is a deprecated empty wrapper; the testing
-- session (`runSession`, `request`, `defaultRequest`, `setPath`) now
-- lives in wai-extra's `Network.Wai.Test` (the same wai-test code).
app :: Application
app request respond = do
  result <- try (loadConfig :: IO Config)
  case result of
    Right cfg ->
      respond $ responseLBS status200
               [("Content-Type", "application/json")]
               (encode cfg)
    Left (e :: SomeException) ->
      respond $ responseLBS status400
               [("Content-Type", "application/json")]
               (encode (object
                 [ "error" .= T.takeWhile (/= '\n') (T.pack (show e)) ]))

-- | Run one request against 'app' while the process CWD is a fresh temp
-- directory holding `config.json` = fixture. The original CWD is restored
-- even if the request or an assertion fails (via 'bracket').
withConfigFixture :: String -> IO (Status, BL.ByteString)
withConfigFixture fixture = do
  orig <- getCurrentDirectory
  bracket
    (do tmp <- mkTempDir "docs-live-hs-spec"
        writeFile_ (tmp </> "config.json") fixture
        setCurrentDirectory tmp
        pure tmp)
    (\tmp -> do
      setCurrentDirectory orig      -- restore CWD first (process-global)
      removeDirectoryRecursive tmp) -- best-effort cleanup
    (\_tmp -> do
      resp <- runSession (request (defaultRequest `setPath` "/config")) app
      pure (simpleStatus resp, simpleBody resp))

-- | Minimal temp-directory helper (the 'tmp' package is not installed).
-- Tests run sequentially, so a directory derived from a process-local
-- counter is unique enough.
tmpCounter :: IORef Int
tmpCounter = unsafePerformIO (newIORef 0)
{-# NOINLINE tmpCounter #-}

mkTempDir :: String -> IO FilePath
mkTempDir prefix = do
  base' <- lookupEnv "TMPDIR"
  let base0 = fromMaybe "/tmp" base'
  n     <- atomicModifyIORef' tmpCounter (\c -> (c + 1, c))
  let cand = base0 </> prefix ++ "-" ++ show n
  createDirectoryIfMissing False cand
  return cand

writeFile_ :: FilePath -> String -> IO ()
writeFile_ path s = do
  h <- openFile path WriteMode
  hPutStr h s
  hClose h

validFixture, invalidFixture :: String
validFixture =
  "{\n"
  <> "  \"name\": \"test-app\",\n"
  <> "  \"port\": 8123,\n"
  <> "  \"adminEmail\": \"admin@example.com\"\n"
  <> "}\n"
invalidFixture = "{not json\n"

main :: IO ()
main = hspec $ do
  it "returns 200 with the exact fixture values for a valid config" $ do
    (st, bs) <- withConfigFixture validFixture
    st `shouldBe` status200
    let cfg :: Maybe Config
        cfg = decode bs
    -- Config only derives Generic (no Eq/Show in the library), so we
    -- assert on the individual fields.
    case cfg of
      Nothing -> fail "body did not decode to a Config"
      Just c  -> do
        name c       `shouldBe` "test-app"
        port c       `shouldBe` 8123
        adminEmail c `shouldBe` "admin@example.com"

  -- NOTE: the two tests are deliberately kept OUTSIDE any `parallel`
  -- block: they mutate the process-wide CWD and must run sequentially.
  it "returns 400 with a JSON error body for a malformed config" $ do
    (st, bs) <- withConfigFixture invalidFixture
    st `shouldBe` status400
    let body :: Maybe Value
        body = decode bs
    -- The body must be a non-empty JSON object. We do not pin the exact
    -- key or message; the real handler emits a single-key JSON object.
    case body of
      Just (Object o) -> not (null (toList o))
      _               -> False
      `shouldBe` True
