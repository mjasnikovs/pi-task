---
id: TASK_AUTO_0001
state: in_progress
phase: done
created_at: 2026-09-06T03:25:10.532Z
updated_at: 2026-09-06T03:37:42.731Z
title: Build a config module in Haskell. It must: (1) expose loadConfig that reads config.json from the project root and decodes it with aeson into a Config record holding a Text name, an Int port and a Text adminEmail; (2) expose a scotty application serving GET /config, which returns the config as JSON on success and HTTP 400 with a JSON error body when config.json fails to decode; (3) cover both responses in test/Spec.hs, passing under `cabal test`.
---

## feature prompt

Build a config module in Haskell. It must: (1) expose loadConfig that reads config.json from the project root and decodes it with aeson into a Config record holding a Text name, an Int port and a Text adminEmail; (2) expose a scotty application serving GET /config, which returns the config as JSON on success and HTTP 400 with a JSON error body when config.json fails to decode; (3) cover both responses in test/Spec.hs, passing under `cabal test`.

## clarifications

Q1: Should loadConfig take the config file path as a parameter (with a "config.json"-at-root default), or hardcode "config.json" at the project root? This is the fork that most changes the test task: an injectable path lets test/Spec.hs point at a well-formed and a deliberately malformed fixture to exercise both the 200 JSON body and the 400 error body without a real config.json being committed to the repo root, whereas a hardcoded path forces the happy path to depend on a checked-in file and leaves the 400 branch hard to reach.
A1: injectable path — `loadConfig :: FilePath -> IO Config` (or `Either String Config`), with the scotty app calling `loadConfig "config.json"` at the module top level. This makes test/Spec.hs point at a well-formed fixture (200) and a deliberately malformed fixture (400) deterministically, with no file-system swapping and no dependency on a committed root config.json. The task's phrasing "reads config.json from the project root" describes the production default, not a zero-arg signature, and the hard requirement to cover both response branches cleanly in `cabal test` effectively forces an injectable path. (auto-resolved — already settled by the spec)
Q2: Should the scotty app read config per-request (makeApp :: FilePath -> ScottyApp, handler calls loadConfig on every GET) or load it once at startup and close over the result (makeApp :: Either String Config -> ScottyApp, with main doing the loadConfig "config.json" IO before calling scotty)? This decides the scotty task's exported signature and how test/Spec.hs builds its two apps (two FilePaths vs. two pre-built Either values), and whether main has an IO step before scotty.
A2: Per-request (makeApp :: FilePath -> ScottyApp, handler calls loadConfig on each GET) — the task specifies the endpoint itself returns 200 "on success" or 400 "when config.json fails to decode," which implies the decode is attempted at request time; tests simply point the app at a valid file and a malformed file. (auto-resolved — already settled by the spec)
Q3: How should test/Spec.hs actually drive the ScottyApp to produce real HTTP 200 and 400 response bodies? The spec demands covering both *responses* (status + JSON body), but a ScottyApp is not itself a WAI Application you can call directly; the standard way to get real statuses/bodies is to wrap it with scottyApp and run it through wai-test's withTestApp. This decides whether the test task adds a wai-test dependency and depends on the ScottyApp being exposed in a scottyApp-callable form, versus testing a refactored handler helper.
A3: Wrap the ScottyApp with scottyApp to obtain a WAI Application, then drive it with wai-test's withTestApp to issue real GET /config requests and assert on both the HTTP status (200 / 400) and the JSON body. Add wai-test to the test-build-depends in the .cabal file. This is the only way to get real status codes and bodies out of a ScottyApp as the task specifies ("expose a scotty application" + "cover both responses"), and it is the idiomatic Scotty testing pattern; the alternative (refactoring handlers into pure helpers) would contradict the task's stated architecture of exposing a ScottyApp. (auto-resolved — already settled by the spec)

## tasks

- [x] TASK_0001  Scaffold the cabal project with library and test-suite stanzas — declare aeson, scotty, text, wai-test in build-depends | decisions (explicit user choices — these OVERRIDE the spec doc wherever they conflict; follow them exactly): add wai-test to the test-build-depends in the .cabal file
- [ ] TASK_0002  Implement the Config record and aeson-based loadConfig — Config holds a Text name, an Int port and a Text adminEmail | decisions (explicit user choices — these OVERRIDE the spec doc wherever they conflict; follow them exactly): use an injectable FilePath parameter (loadConfig :: FilePath -> IO (Either String Config)), do not hardcode the path
- [ ] Implement the scotty application serving GET /config — return 200 with JSON config on success, 400 with JSON error body on decode failure | decisions (explicit user choices — these OVERRIDE the spec doc wherever they conflict; follow them exactly): use per-request decode via makeApp :: FilePath -> ScottyApp with the handler calling loadConfig on each GET, do not load config once at startup and close over the result
- [ ] Write test/Spec.hs covering both the 200 and 400 responses, passing under `cabal test` — include a well-formed and a deliberately malformed JSON fixture | decisions (explicit user choices — these OVERRIDE the spec doc wherever they conflict; follow them exactly): wrap the ScottyApp with scottyApp and drive via wai-test's withTestApp, do not refactor handlers into pure helpers; point the app at well-formed and deliberately malformed fixture files, do not depend on a committed root config.json

## coverage

4 grounded requirement(s): 4 task-mapped, 0 cross-cutting (carried into every task via .pi-tasks/requirements.md), 0 unowned
