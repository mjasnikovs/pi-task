{-# LANGUAGE DeriveGeneric #-}

module Main where

import Control.Exception (try, IOException)
import Data.Aeson
       (FromJSON (..), eitherDecodeStrictText, defaultOptions, genericParseJSON)
import Data.Text (Text, pack)
import GHC.Generics (Generic)
import System.IO (readFile)

-- | Application configuration.
data Config = Config
    { name       :: Text
    , port       :: Int
    , adminEmail :: Text
    } deriving (Generic)

instance FromJSON Config where
    parseJSON = genericParseJSON defaultOptions

-- | Read and decode a config file. Returns a descriptive error on any
-- failure (missing/unreadable file or malformed JSON); never throws.
loadConfig :: FilePath -> IO (Either String Config)
loadConfig path = do
    contents <- try (readFile path) :: IO (Either IOException String)
    case contents of
        Left e ->
            return . Left $ "Failed to read config file '" ++ path
                            ++ "': " ++ show e
        Right s ->
            case eitherDecodeStrictText (pack s) of
                Left err ->
                    return . Left $ "Failed to decode config file '" ++ path
                                    ++ "': " ++ err
                Right cfg -> return . Right $ cfg

main :: IO ()
main = pure ()
