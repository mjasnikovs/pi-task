---
id: TASK_AUTO_0001
state: completed
phase: done
created_at: 2026-09-06T02:35:35.687Z
updated_at: 2026-09-06T03:06:03.605Z
title: Build a config module in Rust. It must: (1) expose load_config() that reads config.json from the crate root and deserializes it with serde into a Config struct holding a String name, a u16 port and a String admin_email; (2) expose an axum Router serving GET /config, which returns the config as JSON on success and HTTP 400 with a JSON error body when config.json fails to parse; (3) cover both responses in tests/config.rs, passing under `cargo test`.
---

## feature prompt

Build a config module in Rust. It must: (1) expose load_config() that reads config.json from the crate root and deserializes it with serde into a Config struct holding a String name, a u16 port and a String admin_email; (2) expose an axum Router serving GET /config, which returns the config as JSON on success and HTTP 400 with a JSON error body when config.json fails to parse; (3) cover both responses in tests/config.rs, passing under `cargo test`.

## clarifications

Q1: Should this crate be restructured to add a library target (src/lib.rs) that both main.rs and tests/config.rs depend on? This is decisive for the breakdown: integration tests in tests/ can only call public items of a *library* crate, not a binary-only crate, so whether we get a lib target up front determines whether "expose load_config()" and "expose the axum Router" are just pub functions inside main.rs (untestable from tests/) or a shared module that a separate "wire up lib + main" task must create first — and it sets the ordering of the config, router, and test tasks.
A1: Yes — restructure to add a library target (src/lib.rs) with `pub mod config` (exposing `load_config`) and the Router builder as pub items; the integration test in tests/config.rs can only call public items of a library crate, so a binary-only crate would make "expose load_config()" and the Router untestable from tests/. Create the lib target first, then the config, router, and test tasks build on it. (auto-resolved — already settled by the spec)
Q2: How does the 400-test deterministically hit the parse-failure path when load_config() reads a fixed config.json at the crate root? Both tests run in parallel under cargo test, and the success test needs the current valid config.json (note: it uses the key adminEmail, so Config will need #[serde(rename = "adminEmail")] — or the file is edited — for the success case to deserialize at all), so the 400 test either manipulates the shared file or needs an injection point; this decides the lib's public API surface and whether the router test task gets a clean fixture-based design or a file-swap design.
A2: widen the lib slightly for testability — pub fn load_config_from(path: &Path) -> Result<Config, ...> with load_config() delegating to it at the crate-root path, and a router builder that accepts an optional config path (defaulting to the spec's fixed path) — so tests/config.rs builds the 400-case router against a malformed temp fixture via tower::ServiceExt::oneshot (adds tower as a dev-dependency only), while the public API stays spec-shaped (YOLO)

## tasks

- [x] TASK_0001  Add a library target (src/lib.rs) so integration tests can access public items — create `pub mod config` and a pub Router builder as the shared surface | decisions (explicit user choices — these OVERRIDE the spec doc wherever they conflict; follow them exactly): restructure the crate to add a library target (src/lib.rs) with `pub mod config` and the Router builder as pub items; create the lib target first, then config, router, and test tasks build on it
- [x] TASK_0002  Implement the config module — expose `load_config()` reading config.json from the crate root and deserializing via serde into `Config { name: String, port: u16, admin_email: String }` with `#[serde(rename = "adminEmail")]` | decisions (explicit user choices — these OVERRIDE the spec doc wherever they conflict; follow them exactly): expose `pub fn load_config_from(path: &Path) -> Result<Config, …>` with `load_config()` delegating to it at the crate-root path
- [x] TASK_0003  Implement the axum Router — `build_router()` serving GET /config, returning the config as JSON on success and HTTP 400 with a JSON error body when config.json fails to parse | decisions (explicit user choices — these OVERRIDE the spec doc wherever they conflict; follow them exactly): router builder accepts an optional config path defaulting to the crate-root config.json
- [x] TASK_0004  Write tests/config.rs covering both the 200 success response and the 400 parse-failure response, passing under `cargo test` | decisions (explicit user choices — these OVERRIDE the spec doc wherever they conflict; follow them exactly): build the 400-case router against a malformed temp fixture via `tower::ServiceExt::oneshot`; add tower as a dev-dependency only

## coverage

4 grounded requirement(s): 4 task-mapped, 0 cross-cutting (carried into every task via .pi-tasks/requirements.md), 0 unowned

## gates

- 2026-09-06T03:06:03.603Z final-gate: PASS — statics + `cargo metadata --locked --format-version 1`, `cargo test --quiet`, `cargo build --quiet` passed
