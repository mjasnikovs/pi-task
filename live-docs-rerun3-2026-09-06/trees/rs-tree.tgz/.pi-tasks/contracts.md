"expose load_config() that reads config.json from the crate root and deserializes it with serde into a Config struct holding a String name, a u16 port and a String admin_email" [anchor: (1)]
"serving GET /config" [anchor: (2)]
"returns the config as JSON on success and HTTP 400 with a JSON error body when config.json fails to parse" [anchor: (2)]
"cover both responses in tests/config.rs, passing under `cargo test`" [anchor: (3)]
