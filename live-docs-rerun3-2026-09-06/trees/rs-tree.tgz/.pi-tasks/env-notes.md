cargo on this machine resolves crates via a local patch at /tmp/crate-patches (e.g. tower 0.5.3), and `cargo build` rewrites Cargo.lock to drop source/checksum lines for locally-resolved packages.	TASK_0001
`cargo` builds the crate from a fresh copy (no target dir) in ~6s on this machine.	TASK_0001
`cargo build`/`cargo test` for the docs-live-rs crate complete in well under 6s on this machine with warm target dir; crate compiles clean with local cargo resolution.	TASK_0002
cargo build of the docs-live-rs crate and dependent probe binaries on this machine completes in ~9s; local crate resolution at /tmp/crate-patches re-confirmed working (probe projects path-depended on the crate and built clean).	TASK_0003
cargo 1.98.1 with local crate patches at /tmp/crate-patches resolves docs-live-rs deps; builds/tests with warm target dir complete in <1s on this machine.	TASK_0004
