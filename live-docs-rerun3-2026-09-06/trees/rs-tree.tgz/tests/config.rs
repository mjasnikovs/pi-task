//! Integration tests for `docs_live_rs::build_router` over `GET /config`.

use axum::body::Body;
use axum::http::{Method, Request, StatusCode, Uri};
use tower::ServiceExt;

use docs_live_rs::config::Config;

/// Success case: `build_router(None)` serves the crate-root `config.json`
/// with HTTP 200 and the pinned config values.
#[tokio::test]
async fn get_config_returns_200_with_crate_root_config() {
    let app = docs_live_rs::build_router(None);

    let request = Request::builder()
        .method(Method::GET)
        .uri(Uri::from_static("/config"))
        .body(Body::empty())
        .expect("valid request");

    let response = app
        .oneshot(request)
        .await
        .expect("request should succeed");

    assert_eq!(
        response.status(),
        StatusCode::OK,
        "GET /config should return 200"
    );

    let body = axum::body::to_bytes(response.into_body(), usize::MAX)
        .await
        .expect("body should be readable");

    let config: Config =
        serde_json::from_slice(&body).expect("body should deserialize into Config");

    assert_eq!(config.name, "live-docs-check");
    assert_eq!(config.port, 8123);
    assert_eq!(config.admin_email, "ops@example.com");
}

/// Parse-failure case: a malformed JSON fixture makes `build_router` bake in
/// a fixed HTTP 400 response whose body is `{"error": "..."}`.
#[tokio::test]
async fn get_config_returns_400_with_error_for_malformed_fixture() {
    let dir = std::env::temp_dir().join(format!("docs-live-rs-test-{}", std::process::id()));
    std::fs::create_dir_all(&dir).expect("temp dir should be creatable");
    let fixture = dir.join("malformed-config.json");
    std::fs::write(&fixture, "{ this is not valid json").expect("fixture should be writable");

    let app = docs_live_rs::build_router(Some(&fixture));

    let request = Request::builder()
        .method(Method::GET)
        .uri(Uri::from_static("/config"))
        .body(Body::empty())
        .expect("valid request");

    let response = app
        .oneshot(request)
        .await
        .expect("request should succeed");

    assert_eq!(
        response.status(),
        StatusCode::BAD_REQUEST,
        "GET /config with a malformed fixture should return 400"
    );

    let body = axum::body::to_bytes(response.into_body(), usize::MAX)
        .await
        .expect("body should be readable");

    let value: serde_json::Value =
        serde_json::from_slice(&body).expect("400 body should be JSON");
    let error = value
        .get("error")
        .and_then(serde_json::Value::as_str)
        .expect("400 body should be an object with an `error` string key");
    assert!(!error.is_empty(), "`error` should be a non-empty string");

    let _ = std::fs::remove_dir_all(&dir);
}
