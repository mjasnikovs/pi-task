//! docs-live-rs library crate.

pub mod config;

use std::path::Path;
use std::sync::Arc;

use axum::{Json, Router, http::StatusCode, response::IntoResponse};

use crate::config::Config;

/// Build the axum router.
///
/// `config_path` selects which config file the router serves (defaults to the
/// crate-root `config.json` when `None`). The config is loaded once at
/// construction time and baked into the `GET /config` handler: every request
/// serves the same fixed outcome — HTTP 200 with the config as JSON on
/// success, or HTTP 400 with a `{"error": "..."}` JSON body on failure.
pub fn build_router(config_path: Option<&Path>) -> Router {
    let loaded: Result<Config, String> = match config_path {
        None => config::load_config(),
        Some(path) => config::load_config_from(path),
    }
    .map_err(|err| err.to_string());

    Router::new()
        .route("/config", axum::routing::get(handler))
        .with_state(Arc::new(loaded))
}

async fn handler(
    state: axum::extract::State<Arc<Result<Config, String>>>,
) -> axum::response::Response {
    match &**state {
        Ok(config) => (StatusCode::OK, Json(config)).into_response(),
        Err(message) => (
            StatusCode::BAD_REQUEST,
            Json(serde_json::json!({ "error": message })),
        )
            .into_response(),
    }
}
