fn main() { let _ = docs_live_rs::build_router(None); }
