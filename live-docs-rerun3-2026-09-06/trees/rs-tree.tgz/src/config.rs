//! Config module for `docs-live-rs`.
//!
//! Loads the crate-root `config.json` (or an arbitrary path) into a
//! [`Config`] struct via serde.

use std::path::Path;

use serde::{Deserialize, Serialize};

/// Application configuration, deserialized from `config.json`.
#[derive(Deserialize, Serialize)]
pub struct Config {
    pub name: String,
    pub port: u16,
    #[serde(rename = "adminEmail")]
    pub admin_email: String,
}

/// Errors that can occur while loading a config file.
#[derive(Debug)]
pub enum ConfigError {
    /// The config file could not be read from disk.
    Io(std::io::Error),
    /// The config file contents are not valid JSON for [`Config`].
    Parse(serde_json::Error),
}

impl std::fmt::Display for ConfigError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            ConfigError::Io(err) => write!(f, "failed to read config file: {err}"),
            ConfigError::Parse(err) => write!(f, "failed to parse config file: {err}"),
        }
    }
}

impl std::error::Error for ConfigError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            ConfigError::Io(err) => Some(err),
            ConfigError::Parse(err) => Some(err),
        }
    }
}

impl From<std::io::Error> for ConfigError {
    fn from(err: std::io::Error) -> Self {
        ConfigError::Io(err)
    }
}

impl From<serde_json::Error> for ConfigError {
    fn from(err: serde_json::Error) -> Self {
        ConfigError::Parse(err)
    }
}

/// Read and deserialize the config file at `path`.
pub fn load_config_from(path: &Path) -> Result<Config, ConfigError> {
    let contents = std::fs::read_to_string(path)?;
    let config = serde_json::from_str(&contents)?;
    Ok(config)
}

/// Load the crate-root `config.json`.
///
/// The path is resolved against the crate manifest directory, so this works
/// regardless of the current working directory.
pub fn load_config() -> Result<Config, ConfigError> {
    let path = Path::new(concat!(env!("CARGO_MANIFEST_DIR"), "/config.json"));
    load_config_from(path)
}
