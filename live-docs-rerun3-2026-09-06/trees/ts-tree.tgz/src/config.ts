import { readFile } from "node:fs/promises";
import { z } from "zod";

export const configSchema = z.object({
  name: z.string(),
  port: z.number().int().min(1).max(65535),
  adminEmail: z.string().email(),
});

export type Config = z.infer<typeof configSchema>;

export class ConfigLoadError extends Error {
  constructor(message: string, readonly cause?: unknown) {
    super(message);
    this.name = "ConfigLoadError";
  }
}

export async function loadConfig(): Promise<Config> {
  const configPath = new URL("../config.json", import.meta.url);
  let raw: string;
  let parsed: unknown;
  try {
    raw = await readFile(configPath, "utf8");
    parsed = JSON.parse(raw);
  } catch (err) {
    throw new ConfigLoadError(`Failed to load config from ${configPath}`, err);
  }
  const result = configSchema.safeParse(parsed);
  if (!result.success) {
    throw result.error;
  }
  return result.data;
}
