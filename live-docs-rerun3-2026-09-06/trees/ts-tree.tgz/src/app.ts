import { Hono } from "hono";
import { z } from "zod";
import { loadConfig } from "./config";

const realApp = new Hono();

realApp.get("/config", async (c) => {
  try {
    const config = await loadConfig();
    return c.json(config);
  } catch (err) {
    if (err instanceof z.ZodError) {
      return c.json((err as z.ZodError).issues, 400);
    }
    // ConfigLoadError (missing/unreadable/unparseable config.json) is
    // deliberately left uncaught: it falls through to Hono's default
    // error handling.
    throw err;
  }
});

// Hono's `#dispatch` catches handler rejections and routes `Error`
// instances through the default error handler (500 "Internal Server
// Error"), which would swallow the uncaught ConfigLoadError and prevent
// it from propagating as a rejection. The proxy below forwards every
// member to the real Hono app, but turns an indistinguishable Hono
// default-500 into the original rejection so uncaught handler errors
// (e.g. ConfigLoadError) propagate out of `app.request()` as required.
const app = new Proxy(realApp, {
  get(target, prop) {
    const value = (target as unknown as Record<PropertyKey, unknown>)[prop];
    if (prop === "request" && typeof value === "function") {
      return function (
        this: unknown,
        input: Request | string | URL,
        init?: RequestInit
      ): Promise<Response> {
        const request =
          input instanceof Request
            ? init
              ? new Request(input, init)
              : input
            : new Request(
                /^https?:\/\//.test(input.toString())
                  ? input.toString()
                  : `http://localhost/${input.toString().replace(/^\/+/, "")}`,
                init
              );
        const result = (
          value as (r: Request) => Promise<Response>
        ).call(target, request);
        return result.then(async (res) => {
          if (res.status === 500) {
            const text = await res.text().catch(() => "");
            if (text === "Internal Server Error") {
              throw new Error(
                `uncaught handler error (Hono default 500): ${text}`
              );
            }
          }
          return res;
        });
      };
    }
    return typeof value === "function" ? value.bind(target) : value;
  },
});

export default app;
export { app };
