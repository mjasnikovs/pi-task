import { test, expect, beforeEach, afterEach } from "bun:test";
import { readFile, writeFile } from "node:fs/promises";
import app from "../src/app";

const configUrl = new URL("../config.json", import.meta.url);
const originalConfig = await readFile(configUrl, "utf8");

// Restore the pristine config before and after each test so the file is
// byte-identical to its committed contents even if an assertion throws.
beforeEach(async () => {
  await writeFile(configUrl, originalConfig, "utf8");
});
afterEach(async () => {
  await writeFile(configUrl, originalConfig, "utf8");
});

test("GET /config returns 200 and the committed config", async () => {
  const res = await app.request("/config");
  expect(res.status).toBe(200);
  await expect(res.json()).resolves.toEqual({
    name: "live-docs-check",
    port: 8123,
    adminEmail: "ops@example.com",
  });
});

test("GET /config returns 400 with zod issues for invalid config", async () => {
  const invalid = JSON.stringify({
    name: "live-docs-check",
    port: 99999,
    adminEmail: "ops@example.com",
  });
  let res: Response | undefined;
  try {
    await writeFile(configUrl, invalid, "utf8");
    res = await app.request("/config");
  } finally {
    await writeFile(configUrl, originalConfig, "utf8");
  }
  expect(res).toBeDefined();
  expect(res!.status).toBe(400);
  const body = await res!.json();
  expect(Array.isArray(body)).toBe(true);
  expect(body.length).toBeGreaterThan(0);
  for (const issue of body) {
    expect(typeof issue.code).toBe("string");
    expect(issue).toHaveProperty("path");
    expect(typeof issue.message).toBe("string");
  }
});
