---
id: TASK_AUTO_0001
state: completed
phase: done
created_at: 2026-09-06T01:37:06.601Z
updated_at: 2026-09-06T02:22:32.836Z
title: Build a config module in TypeScript. It must: (1) export loadConfig() that reads config.json from the project root and validates it with zod, requiring a string name, a port between 1 and 65535, and an admin email; (2) export a hono app serving GET /config, which returns the config as JSON on success and HTTP 400 with the zod validation issues when config.json is invalid; (3) cover both responses in test/config.test.ts, passing under `bun test`.
---

## feature prompt

Build a config module in TypeScript. It must: (1) export loadConfig() that reads config.json from the project root and validates it with zod, requiring a string name, a port between 1 and 65535, and an admin email; (2) export a hono app serving GET /config, which returns the config as JSON on success and HTTP 400 with the zod validation issues when config.json is invalid; (3) cover both responses in test/config.test.ts, passing under `bun test`.

## clarifications

Q1: Should loadConfig() read config.json from a fixed project-root path, or accept an injectable path (e.g. a parameter or env var) so tests can point at a fixture? This is the main remaining fork: it decides whether the test task must create a separate invalid-config fixture and whether the loader and the /config route need a shared way to target different files, which changes how the module is structured and split.
A1: subdivide into smaller per-deliverable tasks — one task per route, page, screen, module, schema, or pipeline stage — rather than one task per milestone or spec section. A milestone or section that spans several deliverables becomes several tasks. (host-set: the spec fixes the build ORDER, not the task breakdown, so pi-task settles granularity deterministically instead of guessing per run) (host-set — plan granularity is not left to chance)

## tasks

- [x] TASK_0001  Build TypeScript config module with zod schema requiring string name, port 1–65535, and admin email
- [x] TASK_0002  Implement loadConfig() reading config.json from project root and validating with zod
- [x] TASK_0003  Export hono app serving GET /config returning config JSON on success or 400 with zod validation issues when invalid
- [x] TASK_0004  Write test/config.test.ts covering both responses, passing under bun test

## coverage

8 grounded requirement(s): 8 task-mapped, 0 cross-cutting (carried into every task via .pi-tasks/requirements.md), 0 unowned

## gates

- 2026-09-06T02:22:32.833Z final-gate: PASS — statics + `npm ci --dry-run` passed
- 2026-09-06T02:22:32.834Z defect STILL OPEN — TASK_0003: auto-ACCEPTED by YOLO mode despite verify-FAIL (unattended — no human weighed this): work did not verify: src/app.ts exports a Proxy over the Hono app that intercepts `request`, sniffs Hono's default 500 "Internal Server Error" body, and throws a synthetic `Error` in its place (comment states the purpose is to make uncaught

