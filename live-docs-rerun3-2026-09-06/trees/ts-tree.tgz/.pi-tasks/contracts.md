"export loadConfig() that reads config.json from the project root and validates it with zod, requiring a string name, a port between 1 and 65535, and an admin email" [anchor: (1)]
"export a hono app serving GET /config, which returns the config as JSON on success and HTTP 400 with the zod validation issues when config.json is invalid" [anchor: (2)]
