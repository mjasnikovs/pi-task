import { describe, expect, test, beforeAll, afterAll, mock } from "bun:test";
import { app } from "../src/app";
import { readFile, writeFile, unlink } from "node:fs/promises";
import { z } from "zod";

const fixturePath = new URL("../test/fixtures/invalid-config.json", import.meta.url).pathname;

// Pinned against installed zod 4.5.4 (captured at runtime for port: 70000).
const pinnedIssues = [
  {
    origin: "number",
    code: "too_big",
    maximum: 65535,
    inclusive: true,
    path: ["port"],
    message: "Too big: expected number to be <=65535",
  },
];

// Reproduce src/config.ts's real loadConfig against an isolated invalid fixture:
// read the file, JSON.parse, and parse with the same schema rules, letting the
// ZodError propagate to the route (which returns c.json(error.issues, 400)).
const configSchema = z.object({
  name: z.string(),
  port: z.number().int().min(1).max(65535),
  adminEmail: z.string(),
});

async function fakeLoadConfig(path: string = fixturePath): Promise<unknown> {
  const raw = await readFile(path, "utf8");
  return configSchema.parse(JSON.parse(raw));
}

beforeAll(async () => {
  // Materialize the invalid fixture (port 70000 breaks max(65535)) at an absolute path.
  await writeFile(
    fixturePath,
    JSON.stringify({ name: "live-docs-check", port: 70000, adminEmail: "ops@example.com" }),
    "utf8",
  );
});

afterAll(async () => {
  await unlink(fixturePath).catch(() => {});
});

describe("GET /config", () => {
  test("returns 200 with the root config.json values when the config is valid", async () => {
    // Runs first, before any mock.module interception: the route reads the
    // genuine root config.json through the real src/config.ts loadConfig.
    const res = await app.request("/config");
    expect(res.status).toBe(200);
    expect(await res.json()).toEqual({
      name: "live-docs-check",
      port: 8123,
      adminEmail: "ops@example.com",
    });
  });

  test("mock intercepts src/app.ts's ./config import and the route 400s on the fixture", async () => {
    const spy = mock(fakeLoadConfig);
    // Intercept the exact specifier src/app.ts uses so the route reads the mock.
    mock.module("../src/config", () => ({ loadConfig: spy }));

    const res = await app.request("/config");
    // Prove the interception actually landed: spy fired, and the route 400'd
    // on the fixture instead of returning a 200 from the untouched root config.
    expect(spy).toHaveBeenCalledTimes(1);
    expect(res.status).toBe(400);
    expect(await res.json()).toEqual(pinnedIssues);
  });

  test("returns 400 with the pinned zod 4.5.4 issues array for an invalid config", async () => {
    const res = await app.request("/config");
    expect(res.status).toBe(400);
    expect(await res.json()).toEqual(pinnedIssues);
  });
});
