bun 1.4.2 at /home/agent/.bun/bin/bun; node available; `bun test` exits 1 (not 0) when zero test files exist in the tree.	TASK_0001
bun 1.4.2 at /home/agent/.bun/bin/bun works for running .ts modules and `bunx tsc --noEmit` in /home/agent/docs-live/run/ts.	TASK_0002
bun 1.4.2 at /home/agent/.bun/bin/bun exits 1 (not 0) when zero test files exist, so `bun test`/`bun run test` cannot pass on a test-less tree in this environment (re-verified in /home/agent/docs-live/run/ts).	TASK_0003
project /home/agent/docs-live/run/ts has no test files in any git commit (git log --all) nor on disk; `bunx tsc --noEmit` passes (exit 0).	TASK_0003
