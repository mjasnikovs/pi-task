import { Hono } from "hono";
import { ZodError } from "zod";
import { loadConfig } from "./config";

export const app = new Hono();

app.get("/config", async (c) => {
  try {
    const config = await loadConfig();
    return c.json(config);
  } catch (error) {
    if (error instanceof ZodError) {
      return c.json(error.issues, 400);
    }
    throw error;
  }
});
