import { readFile } from "node:fs/promises";
import { z } from "zod";

const configPath = new URL("../config.json", import.meta.url).pathname;

const configSchema = z.object({
  name: z.string(),
  port: z.number().int().min(1).max(65535),
  adminEmail: z.string(),
});

export type Config = z.infer<typeof configSchema>;

export async function loadConfig(path: string = configPath): Promise<Config> {
  const raw = await readFile(path, "utf8");
  return configSchema.parse(JSON.parse(raw));
}
