import { describe, expect, test } from "bun:test";
import { app } from "./app";

describe("app module", () => {
  test("exports a Hono app instance", () => {
    expect(typeof (app as { fetch?: unknown }).fetch).toBe("function");
  });
});
