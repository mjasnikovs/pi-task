//! Integration tests for the `GET /config` handler.
//!
//! Uses a temporary config file per test (via `router_with_config`) so the
//! real crate-root `config.json` is never read, mutated, or deleted.
use std::path::PathBuf;

use axum::body::Body;
use axum::http::{Request, StatusCode};
use docs_live_rs::router::router_with_config;
use tower::ServiceExt;

/// Write `contents` to a uniquely-named file in the system temp dir and
/// return its path. The caller is responsible for cleanup.
fn write_temp_file(name: &str, contents: &str) -> PathBuf {
    let mut path = std::env::temp_dir();
    path.push(format!("docs-live-rs-test-{name}-{}.json", std::process::id()));
    std::fs::write(&path, contents).expect("failed to write temp config file");
    path
}

#[tokio::test]
async fn get_config_returns_200_with_camel_case_config() {
    let path = write_temp_file(
        "valid",
        r#"{"name": "temp-config", "port": 4321, "adminEmail": "temp@example.com"}"#,
    );

    let app = router_with_config(&path);

    let response = app
        .oneshot(
            Request::builder()
                .uri("/config")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(response.status(), StatusCode::OK);

    let body = axum::body::to_bytes(response.into_body(), usize::MAX)
        .await
        .unwrap();
    let json: serde_json::Value = serde_json::from_slice(&body).unwrap();
    assert_eq!(
        json,
        serde_json::json!({
            "name": "temp-config",
            "port": 4321,
            "adminEmail": "temp@example.com"
        })
    );

    let _ = std::fs::remove_file(&path);
}

#[tokio::test]
async fn get_config_returns_400_with_json_error_on_bad_config() {
    // Malformed JSON: serde_json cannot parse this into Config.
    let path = write_temp_file("invalid", "{ not valid json !!!");

    let app = router_with_config(&path);

    let response = app
        .oneshot(
            Request::builder()
                .uri("/config")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .unwrap();

    assert_eq!(response.status(), StatusCode::BAD_REQUEST);

    let body = axum::body::to_bytes(response.into_body(), usize::MAX)
        .await
        .unwrap();
    let json: serde_json::Value = serde_json::from_slice(&body).unwrap();
    assert!(json.get("error").and_then(serde_json::Value::as_str).is_some());

    let _ = std::fs::remove_file(&path);
}
