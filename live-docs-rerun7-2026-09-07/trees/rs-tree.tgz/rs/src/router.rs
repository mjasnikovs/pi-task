use std::path::PathBuf;

use axum::extract::State;
use axum::http::StatusCode;
use axum::response::{IntoResponse, Response};
use axum::routing::get;
use axum::Router;

use crate::config::{load_config, Config};

/// Build the application router against the crate-root `config.json`.
pub fn router() -> Router {
    router_with_config("config.json")
}

/// Build the application router against an arbitrary config file path,
/// so tests can inject a temporary config without touching the real one.
pub fn router_with_config(path: impl Into<PathBuf>) -> Router {
    Router::new()
        .route("/config", get(get_config))
        .with_state(path.into())
}

/// Serve the config file (path injected via state) as JSON, re-reading it per request.
async fn get_config(State(path): State<PathBuf>) -> Result<axum::Json<Config>, Response> {
    match load_config(path) {
        Ok(config) => Ok(axum::Json(config)),
        Err(err) => Err((
            StatusCode::BAD_REQUEST,
            axum::Json(serde_json::json!({ "error": err.to_string() })),
        )
            .into_response()),
    }
}
