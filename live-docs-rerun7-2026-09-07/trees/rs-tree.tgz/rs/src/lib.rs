//! Library target for integration tests.
//!
//! Re-exports the `config` and `router` modules so that `router_with_config`,
//! `Config`, and `load_config` are reachable from `tests/config.rs`.
pub mod config;
pub mod router;
