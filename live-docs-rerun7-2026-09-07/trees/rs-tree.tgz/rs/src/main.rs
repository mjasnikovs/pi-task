mod config;
mod router;

use config::load_config;

#[tokio::main]
async fn main() {
    let config = load_config("config.json").expect("failed to load config.json");
    let listener = tokio::net::TcpListener::bind(("127.0.0.1", config.port))
        .await
        .expect("failed to bind listener");
    axum::serve(listener, router::router())
        .await
        .expect("server failed");
}
