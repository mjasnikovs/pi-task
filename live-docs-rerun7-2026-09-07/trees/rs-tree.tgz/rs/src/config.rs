use std::path::Path;

use serde::{Deserialize, Serialize};

/// Application configuration.
#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(rename_all = "camelCase")]
#[allow(dead_code)] // constructed by later steps (router, tests)
pub struct Config {
    pub name: String,
    pub port: u16,
    pub admin_email: String,
}

/// Load a [`Config`] from the JSON file at `path`.
#[allow(dead_code)]
pub fn load_config(path: impl AsRef<Path>) -> Result<Config, Box<dyn std::error::Error>> {
    let bytes = std::fs::read(path)?;
    let config = serde_json::from_slice(&bytes)?;
    Ok(config)
}
