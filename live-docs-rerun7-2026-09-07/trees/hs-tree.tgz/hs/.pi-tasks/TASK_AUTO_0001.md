---
id: TASK_AUTO_0001
state: in_progress
phase: done
created_at: 2026-09-07T00:07:54.053Z
updated_at: 2026-09-07T00:07:54.107Z
title: Build a config module in Haskell. It must: (1) expose loadConfig that reads config.json from the project root and decodes it with aeson into a Config record holding a Text name, an Int port and a Text adminEmail; (2) expose a scotty application serving GET /config, which returns the config as JSON on success and HTTP 400 with a JSON error body when config.json fails to decode; (3) cover both responses in test/Spec.hs, passing under `cabal test`.
---

## feature prompt

Build a config module in Haskell. It must: (1) expose loadConfig that reads config.json from the project root and decodes it with aeson into a Config record holding a Text name, an Int port and a Text adminEmail; (2) expose a scotty application serving GET /config, which returns the config as JSON on success and HTTP 400 with a JSON error body when config.json fails to decode; (3) cover both responses in test/Spec.hs, passing under `cabal test`.

## clarifications

Q1: How should the config source be made injectable so test/Spec.hs can exercise the decode-failure path and assert the 400 JSON body? Since a decode error at startup can't yield a 400, GET /config must read config per-request; the open question is whether the handler reads a parameterized source or a hardcoded config.json, which decides if there's a "make the source injectable" task and whether the test needs filesystem fixtures.
A1: The scotty app (or its handler) should accept a parameterized config source — e.g. `app :: (IO (Either Text Config)) -> ScottyM ()` — with `main` supplying the real `loadConfig` and the test supplying a stub that returns a `Left` error. This is the standard Haskell dependency-injection idiom, satisfies "reads config.json from the project root" via the production `loadConfig`, avoids fragile filesystem fixtures in Spec.hs, and is the only way to deterministically trigger the 400 path without side effects. (auto-resolved — already settled by the spec)
Q2: How should test/Spec.hs observe the two responses — by extracting a pure handler like configResponse :: Either Text Config -> (Int, Text) that the scotty route wraps (and testing that directly, in the existing bare-main style, no sockets), or by actually running the parameterized scotty app over WAI (runScotty on an ephemeral port) and hitting GET /config with an HTTP client? This is the remaining fork that changes the breakdown: the second option adds dependencies (http-client/http-conduit, port-waiting/async) and a test-harness task, while the first keeps deps to scotty + aeson + text and makes the handler-extraction refactor a prerequisite task for the tests. test/Spec.hs already exists as a plain main :: IO () stub (no hspec), and config.json is present at the project root, so the pure-handler path fits what's there.
A2: extract the pure (status, jsonBody) handler and test it directly in the bare-main Spec.hs (success Right → 200 JSON, Left → 400 JSON error body), leaving loadConfig, the scotty app/main wiring, and the cabal test-suite declaration as their own separate tasks (YOLO)
Q3: Should Config and the pure configResponse handler live in a library component that both the executable and the test suite depend on, or should they stay in the app module with the test suite's hs-source-dirs pointing at the same src/? Cabal test suites can only *import* library modules, never executable modules, so this decides whether a "create/restructure library" task must precede the test task (and force a cabal-file edit in the handler task), or whether the test-suite declaration task stays self-contained.
A3: Use a library component — put the `Config` record, `loadConfig`, and the pure `configResponse` handler in a library module (e.g. `App/Config.hs` under the `library` stanza). The executable (`src/Main.hs`) builds the scotty app and calls `main`, and the test suite imports the same library module. This is the standard Cabal project layout: it is the only clean way to satisfy Cabal's rule that test suites can import library modules but not executable modules, and it is what every scotty/yesod/haskell-boilerplate uses. It keeps the test-suite stanza self-contained (`dependencies: [mylib, ...]`) with no `hs-source-dirs` hacks or double-compilation. (auto-resolved — already settled by the spec)

## tasks

- [ ] TASK_0001  Create App/Config.hs library module — Config record, loadConfig, and pure configResponse | decisions (explicit user choices — these OVERRIDE the spec doc wherever they conflict; follow them exactly): place Config, loadConfig, and configResponse in a library component (App/Config.hs) under the library stanza; extract configResponse as a pure (Either Text Config) → (Int, Text) function testable without sockets or filesystem fixtures
- [ ] Wire scotty executable in src/Main.hs — app accepting a parameterized config source, serving GET /config | decisions (explicit user choices — these OVERRIDE the spec doc wherever they conflict; follow them exactly): make the scotty app accept a parameterized config source (IO (Either Text Config) -> ScottyM ()) with main supplying the real loadConfig; import Config and configResponse from the library module
- [ ] Write test/Spec.hs bare-main tests and cabal test-suite stanza — assert 200 JSON on Right, 400 JSON on Left | decisions (explicit user choices — these OVERRIDE the spec doc wherever they conflict; follow them exactly): test the pure configResponse handler directly in bare-main Spec.hs (no hspec, no sockets, no filesystem fixtures); test suite imports the library module, not the executable; supply a stub config source returning Left to trigger the 400 path deterministically

## coverage

4 grounded requirement(s): 4 task-mapped, 0 cross-cutting (carried into every task via .pi-tasks/requirements.md), 0 unowned
