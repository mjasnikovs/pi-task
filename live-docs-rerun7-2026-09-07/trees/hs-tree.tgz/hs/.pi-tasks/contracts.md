"GET /config" [anchor: (2)]
"a Config record holding a Text name, an Int port and a Text adminEmail" [anchor: (1)]
"expose loadConfig that reads config.json from the project root" [anchor: (1)]
"returns the config as JSON on success and HTTP 400 with a JSON error body when config.json fails to decode" [anchor: (2)]
