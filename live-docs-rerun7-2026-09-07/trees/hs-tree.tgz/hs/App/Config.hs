{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE ScopedTypeVariables #-}
-- | Application configuration: a small JSON-backed record, a
-- non-throwing loader, and a pure (status, body) response mapper.
module App.Config
  ( Config (..),
    loadConfig,
    configResponse,
  )
where

import Control.Exception (SomeException, try)
import Data.Aeson (FromJSON (..), ToJSON (..), Value (..), decode, encode)
import Data.Aeson (object, (.=))
import qualified Data.Aeson.Key as K
import Data.Aeson.Types (Options (..), genericParseJSON, genericToJSON)
import qualified Data.ByteString.Lazy as BL
import Data.Text (Text)
import Data.Text.Encoding (decodeUtf8, encodeUtf8)
import GHC.Generics (Generic)

-- | Application configuration, loaded from "config.json".
data Config = Config
  { name :: Text,
    port :: Int,
    adminEmail :: Text
  }
  deriving (Show, Eq, Generic)

instance FromJSON Config where
  parseJSON = genericParseJSON defaultOptions

instance ToJSON Config where
  toJSON = genericToJSON defaultOptions

-- | Read and decode "config.json" from the project root (current
-- working directory). Never throws: a missing/unreadable file and a
-- decode failure both surface as a 'Left' with a human-readable
-- message.
loadConfig :: IO (Either Text Config)
loadConfig = do
  bs <- try (BL.readFile "config.json")
  case bs of
    Left (e :: SomeException) ->
      pure (Left (toText ("failed to read config.json: " ++ show e)))
    Right contents -> case decode contents of
      Left err -> pure (Left (toText ("failed to decode config.json: " ++ err)))
      Right cfg -> pure (Right cfg)
  where
    toText :: String -> Text
    toText = decodeUtf8 . encodeUtf8

-- | Map a loaded config to an HTTP-style (status code, JSON body) pair:
-- 'Right c' -> (200, c as JSON); 'Left err' -> (400, {"error": err}).
configResponse :: Either Text Config -> (Int, Text)
configResponse (Right cfg) = (200, lazyDecode (encode cfg))
configResponse (Left err)  = (400, lazyDecode (encode (errorBody err)))

errorBody :: Text -> Value
errorBody t = object [(K.fromString "error") .= (t :: Text)]

-- | decodeUtf8 specialised to Lazy.ByteString (aeson encode returns lazy)
lazyDecode :: BL.ByteString -> Text
lazyDecode = decodeUtf8
